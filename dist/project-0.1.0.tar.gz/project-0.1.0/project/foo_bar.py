from .bar import bar
from .src.foo import foo

def foo_bar():
    return foo() + bar()

