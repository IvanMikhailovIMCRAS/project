def foo():
    return 'foo'