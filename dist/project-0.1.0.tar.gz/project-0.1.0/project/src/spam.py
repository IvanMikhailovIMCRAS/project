def spam():
    return 'spam'