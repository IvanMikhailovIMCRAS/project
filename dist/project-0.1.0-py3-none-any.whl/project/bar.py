def bar():
    return 'bar'