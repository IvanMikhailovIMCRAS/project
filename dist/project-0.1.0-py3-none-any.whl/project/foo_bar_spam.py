from .foo_bar import foo_bar
from .src.spam import spam

def foo_bar_spam():
    return foo_bar() + spam() 